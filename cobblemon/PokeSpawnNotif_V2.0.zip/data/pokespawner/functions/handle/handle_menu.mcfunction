##
# handle_menu.mcfunction
# 
# Created by KnightKehan.
##
# Verwijder debug melding voor betere performance
# tellraw @s ["",{"text":"Menu triggered with value: ","color":"gray"},{"score":{"name":"@s","objective":"pokemenu"},"color":"yellow"}]

# Basis menu's - zorg dat deze eerst worden gecontroleerd voor beste performance
execute if entity @s[scores={pokemenu=1}] run function pokespawner:menu/main
execute if entity @s[scores={pokemenu=2}] run function pokespawner:settings/main
execute if entity @s[scores={pokemenu=4}] run function pokespawner:favorites/show_all
execute if entity @s[scores={pokemenu=5}] run function pokespawner:help/main
execute if entity @s[scores={pokemenu=6}] run function pokespawner:utils/search_by_id
execute if entity @s[scores={pokemenu=9}] run function pokespawner:tracking/status

# Favorieten slots en track slot commando's
execute if entity @s[scores={pokemenu=11}] run function pokespawner:favorites/set_slot1
execute if entity @s[scores={pokemenu=12}] run function pokespawner:favorites/set_slot2
execute if entity @s[scores={pokemenu=13}] run function pokespawner:favorites/set_slot3
execute if entity @s[scores={pokemenu=14}] run function pokespawner:favorites/set_slot4
execute if entity @s[scores={pokemenu=15}] run function pokespawner:favorites/set_slot5

execute if entity @s[scores={pokemenu=51}] run function pokespawner:favorites/track_slot1
execute if entity @s[scores={pokemenu=52}] run function pokespawner:favorites/track_slot2
execute if entity @s[scores={pokemenu=53}] run function pokespawner:favorites/track_slot3
execute if entity @s[scores={pokemenu=54}] run function pokespawner:favorites/track_slot4
execute if entity @s[scores={pokemenu=55}] run function pokespawner:favorites/track_slot5

execute if entity @s[scores={pokemenu=11..55}] run function pokespawner:favorites/manage_favorites
execute if entity @s[scores={pokemenu=40}] run function pokespawner:favorites/manage_slots

# Pagina's (101-201 voor pagina's 1-101) - gegroepeerd voor betere performance
execute if score @s pokemenu matches 101.. run function pokespawner:handle/handle_pages